//
//  MADViewController.h
//  task
//
//  Created by Technology, Arts & Meida on 12/16/13.
//  Copyright (c) 2013 steph. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MADViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *task1;
@property (weak, nonatomic) IBOutlet UITextField *task2;
@property (weak, nonatomic) IBOutlet UITextField *task3;
@property (weak, nonatomic) IBOutlet UITextField *task4;

@end
