//
//  main.m
//  numgame
//
//  Created by Technology, Arts & Meida on 10/7/13.
//
//

#import <UIKit/UIKit.h>

#import "MADAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([MADAppDelegate class]));
    }
}
