//
//  MADAppDelegate.h
//  tipcalculator
//
//  Created by Technology, Arts & Meida on 10/7/13.
//
//

#import <UIKit/UIKit.h>

@class MADViewController;

@interface MADAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) MADViewController *viewController;

@end
