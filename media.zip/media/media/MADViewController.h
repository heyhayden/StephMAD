//
//  MADViewController.h
//  media
//
//  Copyright (c) 2013 steph. All rights reserved.
//
#import <MediaPlayer/MediaPlayer.h>
#import <UIKit/UIKit.h>
#import <MobileCoreServices/MobileCoreServices.h>
#import <AVFoundation/AVFoundation.h>
@interface MADViewController : UIViewController
<UIImagePickerControllerDelegate, UIActionSheetDelegate, UINavigationControllerDelegate,AVAudioPlayerDelegate>

@property (weak, nonatomic) IBOutlet UIImageView *imageView;
- (IBAction)cameraButtonTapped:(UIBarButtonItem *)sender;
- (IBAction)actionButtonTapped:(UIBarButtonItem *)sender;

@end
