//
//  MADAppDelegate.h
//  location
//
//  Created by Technology, Arts & Meida on 12/16/13.
//  Copyright (c) 2013 steph. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MADAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
