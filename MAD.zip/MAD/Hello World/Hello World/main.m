//
//  main.m
//  Hello World
//
//  Created by Stephanie Alexis Hayden on 8/29/13.
//  Copyright (c) 2013 Stephanie Alexis Hayden. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "MADAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([MADAppDelegate class]));
    }
}
