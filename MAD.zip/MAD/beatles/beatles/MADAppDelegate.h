//
//  MADAppDelegate.h
//  beatles
//
//  Created by Technology, Arts & Meida on 10/4/13.
//
//

#import <UIKit/UIKit.h>

@class MADViewController;

@interface MADAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) MADViewController *viewController;

@end
