//
//  main.m
//  Hello World 2
//
//  Created by Steph Hayden on 9/25/13.
//  Copyright (c) 2013 Steph Hayden. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "MADAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([MADAppDelegate class]));
    }
}
