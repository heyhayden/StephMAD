//
//  MADViewController.h
//  countries
//
//  Copyright (c) 2013 steph. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MADViewController : UITableViewController
<UITableViewDataSource, UITableViewDelegate>

@end
