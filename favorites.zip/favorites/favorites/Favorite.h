//
//  Favorite.h
//  favorites
//
//  Created by Technology, Arts & Meida on 11/28/13.
//  Copyright (c) 2013 steph. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Favorite : NSObject

@property(copy, nonatomic) NSString *favBook;
@property(copy, nonatomic) NSString *favAuthor;

@end
