//
//  MADAppDelegate.h
//  harrypotter
//
//  Created by Stephanie Alexis Hayden on 10/31/13.
//  Copyright (c) 2013 Stephanie Alexis Hayden. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MADAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
