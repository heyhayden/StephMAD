//
//  main.m
//  harrypotter
//
//  Created by Stephanie Alexis Hayden on 10/31/13.
//  Copyright (c) 2013 Stephanie Alexis Hayden. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "MADAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([MADAppDelegate class]));
    }
}
