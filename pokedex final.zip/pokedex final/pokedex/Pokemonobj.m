//
//  Pokemonobj.m
//  pokedex
//
//  Created by Technology, Arts & Meida on 11/11/13.
//  Copyright (c) 2013 steph. All rights reserved.
//

#import "Pokemonobj.h"

@implementation Pokemonobj

@synthesize name;
@synthesize type;
@synthesize imageFile;
@synthesize stats;

@end
